import random
def calcularPrimeiroDigito(cpf):
    soma = 0
    i = 0

    for cont in range(10, 1, -1):
        soma += (int(cpf[i]) * cont)
        i += 1
    soma = 10 * soma
    primeiroDigito = soma % 11
    if primeiroDigito > 9:
        primeiroDigito = 0
    return primeiroDigito


def calcularSegundoDigito(cpf, primeiroD):
    soma = 0
    i = 0
    cpf = cpf[:9] + str(primeiroD)
    for cont in range(11, 1, -1):
        soma += (int(cpf[i]) * cont)
        i += 1
    soma = 10 * soma
    segundoDigito = soma % 11
    if segundoDigito > 9:
        segundoDigito = 0
    return segundoDigito


def validarCPF(cpf):
    cpf = cpf.replace(".", "").replace("-", "").replace(" ", "")
    cpf_digitos_iguais = cpf[0] * len(cpf)
    if cpf == cpf_digitos_iguais:
        print("CPF inválido: todos os dígitos são iguais")
    else:
        primeiroDigito = calcularPrimeiroDigito(cpf)
        segundoDigito = calcularSegundoDigito(cpf, primeiroDigito)
        if cpf[9] == str(primeiroDigito) and cpf[-1] == str(segundoDigito):
            print("CPF válido")
        else:
            print("CPF inválido")

def gerarCPF():
    cpfGerado = " "
    for i in range(3):
        for c in range(3):
            cpfGerado += str(random.randint(0,9))
        if i < 2:
            cpfGerado += "."
    cpfGerado += "-"
    cpfSomenteNumeros = cpfGerado.replace(".", "").replace("-", "").replace(" ", "")
    primeiroDigito = calcularPrimeiroDigito(cpfSomenteNumeros)
    segundoDigito = calcularSegundoDigito(cpfSomenteNumeros, primeiroDigito)
    cpfGerado += str(primeiroDigito) + str(segundoDigito)
    return cpfGerado

