import funcoesCPF
print("""
    0 - sair
    1 - gerar CPF
    2 - validar CPF
""")

while True:
    opcao = int(input("Opção: "))
    if opcao == 0:
        break
    elif opcao == 1:
        print(funcoesCPF.gerarCPF())
    elif opcao == 2:
        cpf = input("Digite o CPF: ")
        try:
            funcoesCPF.validarCPF(cpf)
        except ValueError:
            print("Por favor, siga o formato e não insira letras (___.___.___-__)")
